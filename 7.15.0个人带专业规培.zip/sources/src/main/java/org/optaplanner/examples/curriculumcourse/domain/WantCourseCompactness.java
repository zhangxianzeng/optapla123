package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WantCourseCompactness")
public class WantCourseCompactness  extends AbstractPersistable{
private Course course;
private int weight;
public Course getCourse() {
	return course;
}

public void setCourse(Course course) {
	this.course = course;
}

public int getWeight() {
	return weight;
}

public void setWeight(int weight) {
	this.weight = weight;
}

@Override
public String toString() {
    return course + "@"+weight;
}

}
