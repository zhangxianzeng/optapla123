/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.optaplanner.examples.curriculumcourse.persistence;

import java.io.IOException;


import org.optaplanner.examples.common.persistence.AbstractXmlSolutionExporter;
import org.optaplanner.examples.common.persistence.SolutionConverter;
import org.optaplanner.examples.curriculumcourse.app.CurriculumCourseApp;

import org.optaplanner.examples.curriculumcourse.domain.CourseSchedule;
import org.optaplanner.examples.curriculumcourse.domain.Lecture;
import org.jdom.Element;
public class CurriculumCourseExporter extends AbstractXmlSolutionExporter<CourseSchedule> {
    public static void main(String[] args) {
        SolutionConverter<CourseSchedule> converter = SolutionConverter.createExportConverter(
                CurriculumCourseApp.DATA_DIR_NAME, CourseSchedule.class, new CurriculumCourseExporter());
        converter.convertAll();
    }

    @Override
    public XmlOutputBuilder<CourseSchedule> createXmlOutputBuilder() {
        return new CurriculumCourseOutputBuilder();
    }

    public static class CurriculumCourseOutputBuilder extends XmlOutputBuilder<CourseSchedule> {
   private CourseSchedule courseSchedule;
   @Override
	public void setSolution(CourseSchedule solution) {
		courseSchedule=solution;
		
	}
        @Override
        public void writeSolution() throws IOException {
        	Element solutionElement = new Element("Solution");
            document.setRootElement(solutionElement);
            for (Lecture lecture : courseSchedule.getLectureList()) {
//                bufferedWriter.write(lecture.getCourse().getCode()
//                        + " r" + lecture.getRoom().getCode()
//                        + " " + lecture.getPeriod().getDay().getDayIndex()
//                        + " " + lecture.getPeriod().getTimeslot().getTimeslotIndex() + "\r\n");
            	 Element assignmentElement = new Element("CourseSchedule");
                 solutionElement.addContent(assignmentElement);
                 
//                 Element lectureElement = new Element("lecture");
//                 lectureElement.setText(lecture.getCourse().getCode());
//                 assignmentElement.addContent(lectureElement);
                 
                 Element roomElement = new Element("room");
                 roomElement.setText(lecture.getRoom().getCode());
                 assignmentElement.addContent(roomElement);
                 
                 
//                 Element weekdayElement = new Element("weekday");
//                 weekdayElement.setText(lecture.getPeriod().getDay().getLabel());
//                assignmentElement.addContent(weekdayElement);
                 
                Element timeslotElement = new Element("timeslot");
                timeslotElement.setText(lecture.getPeriod().getTimeslot().getLabel());
               assignmentElement.addContent(timeslotElement);
               //增加时间段
//               Element timesElement = new Element("times");
//               timesElement.setText(lecture.getPeriod().getTimeslot().getTime());
//              assignmentElement.addContent(timesElement);
              
               
               Element teacherlotElement = new Element("teacher");
               teacherlotElement.setText(lecture.getTeacher().getCode() );
              assignmentElement.addContent(teacherlotElement);
              
              Element curriculumlotElement = new Element("curriculum");
              //curriculumlotElement.setText(lecture.getCurriculumList().toString().toString() );
              curriculumlotElement.setText(lecture.getCurriculum().getCode() );
             assignmentElement.addContent(curriculumlotElement);
            }
        }

		
    }

}
