/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.optaplanner.examples.curriculumcourse.app;

import java.io.FileOutputStream;
import java.io.PrintStream;

import org.optaplanner.examples.common.app.CommonApp;
import org.optaplanner.examples.common.business.SolutionBusiness;
import org.optaplanner.examples.common.persistence.AbstractSolutionExporter;
import org.optaplanner.examples.common.persistence.AbstractSolutionImporter;
import org.optaplanner.examples.common.swingui.SolverAndPersistence;
import org.optaplanner.examples.curriculumcourse.domain.CourseSchedule;
import org.optaplanner.examples.curriculumcourse.persistence.CurriculumCourseExporter;
import org.optaplanner.examples.curriculumcourse.persistence.CurriculumCourseImporter;
import org.optaplanner.examples.curriculumcourse.swingui.CurriculumCoursePanel;
import org.optaplanner.persistence.common.api.domain.solution.SolutionFileIO;
import org.optaplanner.persistence.xstream.impl.domain.solution.XStreamSolutionFileIO;

public class CurriculumCourseApp extends CommonApp<CourseSchedule> {

    public static final String SOLVER_CONFIG
            = "org/optaplanner/examples/curriculumcourse/solver/curriculumCourseSolverConfig.xml";
    public CurriculumCourseApp() {
        super("Course timetabling",
                "Official competition name: ITC 2007 track3 - Curriculum course scheduling\n\n" +
                        "Assign lectures to periods and rooms.",
                SOLVER_CONFIG, DATA_DIR_NAME,
                CurriculumCoursePanel.LOGO_PATH);
    }

    public static final String DATA_DIR_NAME = "curriculumcourse";

//  public static void main(String[] args){
//  	if (args.length == 0) return;
//	PrintStream stddOut = System.out;
//		PrintStream ps = null;
//	PrintStream pss = null;
//	try {
//		ps = stddOut;
//		//ps = new PrintStream(new FileOutputStream("/data/logs/Curriculumcourse.log", true));
//	} catch (Exception e) {
//		//System.out.println("/data/logs/Curriculumcourse.log not exist.");
//		return;
//		}
//		pss = stddOut;
//			try {
//		//pss = new PrintStream(new FileOutputStream("/data/logs/Curriculumcourse.debug.log", true));
//	} catch (Exception e) {
//		e.printStackTrace(ps);
//	}
//		
// 	int seconds = 0;
//   	if (args.length >= 2) {
//		try {
//				seconds = Integer.parseInt(args[1]);
//			} catch (Exception e) {
//				e.printStackTrace(ps);
//			}
//   	}
//    	System.setOut(pss);
//		String filePath = new CurriculumCourseApp().init(args[0], stddOut, ps, seconds);
//		System.out.println(filePath);
//		ps.close();
//		pss.close();
//		System.exit(0);
//		}
//    public String init(String path, PrintStream stddOut, PrintStream ps, int secondes) {
//        solutionBusiness = createSolutionBusiness();
//         solverAndPersistence = new SolverAndPersistence<>(solutionBusiness);
//        return solverAndPersistence.init(path, stddOut, ps, secondes);
//   } 
//
//    public SolutionBusiness<CourseSchedule> createSolutionBusiness() {
//        SolutionBusiness<CourseSchedule> solutionBusiness = new SolutionBusiness<>(this);
//        solutionBusiness.setSolutionFileIO(createSolutionFileIO());
//       solutionBusiness.setExporter(createSolutionExporter());
//       solutionBusiness.setSolver(createSolver());
//       return solutionBusiness;
//}

    public static void main(String[] args) {
        prepareSwingEnvironment();

        new CurriculumCourseApp().init();
    }
    @Override
    protected CurriculumCoursePanel createSolutionPanel() {
        return new CurriculumCoursePanel();
    }

    @Override
    public SolutionFileIO<CourseSchedule> createSolutionFileIO() {
        return new XStreamSolutionFileIO<>(CourseSchedule.class);
    }

    @Override
    protected AbstractSolutionImporter[] createSolutionImporters() {
        return new AbstractSolutionImporter[]{
                new CurriculumCourseImporter()
        };
    }

    @Override
    protected AbstractSolutionExporter createSolutionExporter() {
        return new CurriculumCourseExporter();
    }

}
