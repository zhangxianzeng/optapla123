package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("AWeekBestNoCourse")
public class AWeekBestNoCourse  extends AbstractPersistable{

    private AWeek aweek;
    private int weight;
    
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
	
	@Override
    public String toString() {
        return  aweek+"@"+weight;
    }
	public AWeek getAweek() {
		return aweek;
	}
	public void setAweek(AWeek aweek) {
		this.aweek = aweek;
	}
}
