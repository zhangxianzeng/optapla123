/*
 * Copyright 2016 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.optaplanner.examples.curriculumcourse.domain;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import org.optaplanner.core.api.domain.solution.PlanningEntityCollectionProperty;
import org.optaplanner.core.api.domain.solution.PlanningScore;
import org.optaplanner.core.api.domain.solution.PlanningSolution;
import org.optaplanner.core.api.domain.solution.drools.ProblemFactCollectionProperty;
import org.optaplanner.core.api.domain.valuerange.ValueRangeProvider;
import org.optaplanner.core.api.score.buildin.hardsoft.HardSoftScore;
import org.optaplanner.examples.common.domain.AbstractPersistable;
import org.optaplanner.examples.curriculumcourse.domain.solver.CourseConflict;
import org.optaplanner.persistence.xstream.api.score.buildin.hardsoft.HardSoftScoreXStreamConverter;

@PlanningSolution

@XStreamAlias("CourseSchedule")
public class CourseSchedule extends AbstractPersistable {

    private String name;

    private List<Teacher> teacherList;
    private List<Major> majorList;
    private List<Coursenature> coursenatureList;
    private List<Curriculum> curriculumList;
    private List<Course> courseList;
    private List<Week> weekList;
    private List<AWeek> aweekList;
    private List<Day> dayList;
    private List<WeekCourse> weekCourseList;
    private List<Timeslot> timeslotList;
    private List<Period> periodList;
    private List<Room> roomList;
    private List<Subject> subjectList;
    private List<UnavailablePeriodPenalty> unavailablePeriodPenaltyList;
    private List<WantavailablePeriodPenalty> wantavailablePeriodPenaltyList;
    private List<WantavailableRoomPenalty> wantavailableRoomPenaltyList;
    private List<UnavailableRoomPenalty> unavailableRoomPenaltyList;
    private List<WantavailableCoursenaturePenalty> wantavailableCoursenaturePenaltyList;
    private List<UnavailableCoursenaturePenalty> unavailableCoursenaturePenaltyList;
    private List<WantCourseCompactness> wantCourseCompactnessList;
    private List<UnavailablePeriodPenaltySubject> unavailablePeriodPenaltySubjectList;
    private List<WantavailablePeriodPenaltySubject> wantavailablePeriodPenaltySubjectList;
    private List<WantTwoCourseCompactness> wantTwoCourseCompactnessList;
    private List<WantavailableTeacherTimeslotPenalty> wantavailableTeacherTimeslotPenaltyList;
    private List<UnavailableTeacherTimeslotPenalty> unavailableTeacherTimeslotPenaltyList;
    private List<UnavailableTimeslotPenaltySubject> unavailableTimeslotPenaltySubjectList;
    private List<WantavailableTimeslotPenaltySubject> wantavailableTimeslotPenaltySubjectList;
    private List<WantavailabletimeslotPenaltyCoursenature> wantavailabletimeslotPenaltyCoursenatureList;
    private List<WantavailabletimeslotPenaltyNoCourse> wantavailabletimeslotPenaltyNoCourseList;
    private List<WantavailableRoomPenaltySubject> wantavailableRoomPenaltySubjectList;
    private List<UnavailableRoomPenaltySubject> unavailableRoomPenaltySubjectList;
    private List<WantCourseCompactnessSubject> wantCourseCompactnessSubjectList;
    private List<WantTwoCourseCompactnessSubject> wantTwoCourseCompactnessSubjectList;
    private List<AWeekBestNoCourse> aweekBestNoCourseList;
    private List<UnCourseCompactness> unCourseCompactnessList;
    private List<WantavailablePeriodPenalty1> wantavailablePeriodPenaltyList1;
    private List<Lecture> lectureList;

    @XStreamConverter(HardSoftScoreXStreamConverter.class)
    private HardSoftScore score;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @ProblemFactCollectionProperty
    public List<Teacher> getTeacherList() {
        return teacherList;
    }

    public void setTeacherList(List<Teacher> teacherList) {
        this.teacherList = teacherList;
    }
    @ProblemFactCollectionProperty
    public List<Major> getMajorList() {
		return majorList;
	}

	public void setMajorList(List<Major> majorList) {
		this.majorList = majorList;
	}
	 @ProblemFactCollectionProperty
	public List<Coursenature> getCoursenatureList() {
		return coursenatureList;
	}

	public void setCoursenatureList(List<Coursenature> coursenatureList) {
		this.coursenatureList = coursenatureList;
	}

    @ProblemFactCollectionProperty
    public List<Curriculum> getCurriculumList() {
        return curriculumList;
    }

    public void setCurriculumList(List<Curriculum> curriculumList) {
        this.curriculumList = curriculumList;
    }
    @ProblemFactCollectionProperty
	public List<Subject> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}

    @ProblemFactCollectionProperty
    public List<Course> getCourseList() {
        return courseList;
    }

    public void setCourseList(List<Course> courseList) {
        this.courseList = courseList;
    }

    @ProblemFactCollectionProperty
    public List<Day> getDayList() {
        return dayList;
    }

    public void setDayList(List<Day> dayList) {
        this.dayList = dayList;
    }
    @ProblemFactCollectionProperty
    public List<AWeek> getAweekList() {
		return aweekList;
	}

	public void setAweekList(List<AWeek> aweekList) {
		this.aweekList = aweekList;
	}
    
    @ProblemFactCollectionProperty
    public List<Timeslot> getTimeslotList() {
        return timeslotList;
    }

    public void setTimeslotList(List<Timeslot> timeslotList) {
        this.timeslotList = timeslotList;
    }

    @ValueRangeProvider(id = "periodRange")
    @ProblemFactCollectionProperty
    public List<Period> getPeriodList() {
        return periodList;
    }

    public void setPeriodList(List<Period> periodList) {
        this.periodList = periodList;
    }

    @ValueRangeProvider(id = "roomRange")
    @ProblemFactCollectionProperty
    public List<Room> getRoomList() {
        return roomList;
    }

    public void setRoomList(List<Room> roomList) {
        this.roomList = roomList;
    }

    @ProblemFactCollectionProperty
    public List<UnavailablePeriodPenalty> getUnavailablePeriodPenaltyList() {
        return unavailablePeriodPenaltyList;
    }

    public void setUnavailablePeriodPenaltyList(List<UnavailablePeriodPenalty> unavailablePeriodPenaltyList) {
        this.unavailablePeriodPenaltyList = unavailablePeriodPenaltyList;
    } 
    @ProblemFactCollectionProperty
    public List<WantavailablePeriodPenalty> getWantavailablePeriodPenaltyList() {
		return wantavailablePeriodPenaltyList;
	}

	public void setWantavailablePeriodPenaltyList(List<WantavailablePeriodPenalty> wantavailablePeriodPenaltyList) {
		this.wantavailablePeriodPenaltyList = wantavailablePeriodPenaltyList;
	}
    @ProblemFactCollectionProperty
	public List<WantavailableRoomPenalty> getWantavailableRoomPenaltyList() {
		return wantavailableRoomPenaltyList;
	}

	public void setWantavailableRoomPenaltyList(List<WantavailableRoomPenalty> wantavailableRoomPenaltyList) {
		this.wantavailableRoomPenaltyList = wantavailableRoomPenaltyList;
	}
	@ProblemFactCollectionProperty
	public List<UnavailableRoomPenalty> getUnavailableRoomPenaltyList() {
		return unavailableRoomPenaltyList;
	}

	public void setUnavailableRoomPenaltyList(List<UnavailableRoomPenalty> unavailableRoomPenaltyList) {
		this.unavailableRoomPenaltyList = unavailableRoomPenaltyList;
	}
	
	@ProblemFactCollectionProperty
	public List<UnavailableTeacherTimeslotPenalty> getUnavailableTeacherTimeslotPenaltyList() {
		return unavailableTeacherTimeslotPenaltyList;
	}

	public void setUnavailableTeacherTimeslotPenaltyList(List<UnavailableTeacherTimeslotPenalty> unavailableTeacherTimeslotPenaltyList) {
		this.unavailableTeacherTimeslotPenaltyList = unavailableTeacherTimeslotPenaltyList;
	}
	@ProblemFactCollectionProperty
	public List<WantCourseCompactness> getWantCourseCompactnessList() {
		return wantCourseCompactnessList;
	}

	public void setWantCourseCompactnessList(List<WantCourseCompactness> wantCourseCompactnessList) {
		this.wantCourseCompactnessList = wantCourseCompactnessList;
	}
	@ProblemFactCollectionProperty
	public List<WantTwoCourseCompactness> getWantTwoCourseCompactnessList() {
		return wantTwoCourseCompactnessList;
	}

	public void setWantTwoCourseCompactnessList(List<WantTwoCourseCompactness> wantTwoCourseCompactnessList) {
		this.wantTwoCourseCompactnessList = wantTwoCourseCompactnessList;
	}
	@ProblemFactCollectionProperty
	public List<WeekCourse> getWeekCourseList() {
		return weekCourseList;
	}

	public void setWeekCourseList(List<WeekCourse> weekCourseList) {
		this.weekCourseList = weekCourseList;
	}

	   @ValueRangeProvider(id = "weekRange")
	    @ProblemFactCollectionProperty
	public List<Week> getWeekList() {
		return weekList;
	}

	public void setWeekList(List<Week> weekList) {
		this.weekList = weekList;
	}

	@ProblemFactCollectionProperty
	public List<UnavailableCoursenaturePenalty> getUnavailableCoursenaturePenaltyList() {
		return unavailableCoursenaturePenaltyList;
	}

	public void setUnavailableCoursenaturePenaltyList(List<UnavailableCoursenaturePenalty> unavailableCoursenaturePenaltyList) {
		this.unavailableCoursenaturePenaltyList = unavailableCoursenaturePenaltyList;
	}

	@ProblemFactCollectionProperty
	public List<WantavailableCoursenaturePenalty> getWantavailableCoursenaturePenaltyList() {
		return wantavailableCoursenaturePenaltyList;
	}

	public void setWantavailableCoursenaturePenaltyList(List<WantavailableCoursenaturePenalty> wantavailableCoursenaturePenaltyList) {
		this.wantavailableCoursenaturePenaltyList = wantavailableCoursenaturePenaltyList;
	}
	@ProblemFactCollectionProperty
	public List<WantavailableTeacherTimeslotPenalty> getWantavailableTeacherTimeslotPenaltyList() {
		return wantavailableTeacherTimeslotPenaltyList;
	}

	public void setWantavailableTeacherTimeslotPenaltyList(List<WantavailableTeacherTimeslotPenalty> wantavailableTeacherTimeslotPenaltyList) {
		this.wantavailableTeacherTimeslotPenaltyList = wantavailableTeacherTimeslotPenaltyList;
	}

	@ProblemFactCollectionProperty
	public List<UnCourseCompactness> getUnCourseCompactnessList() {
		return unCourseCompactnessList;
	}

	public void setUnCourseCompactnessList(List<UnCourseCompactness> unCourseCompactnessList) {
		this.unCourseCompactnessList = unCourseCompactnessList;
	}
	@ProblemFactCollectionProperty
	public List<WantavailableRoomPenaltySubject> getWantavailableRoomPenaltySubjectList() {
		return wantavailableRoomPenaltySubjectList;
	}

	public void setWantavailableRoomPenaltySubjectList(List<WantavailableRoomPenaltySubject> wantavailableRoomPenaltySubjectList) {
		this.wantavailableRoomPenaltySubjectList = wantavailableRoomPenaltySubjectList;
	}
	@ProblemFactCollectionProperty
	public List<UnavailableRoomPenaltySubject> getUnavailableRoomPenaltySubjectList() {
		return unavailableRoomPenaltySubjectList;
	}

	public void setUnavailableRoomPenaltySubjectList(List<UnavailableRoomPenaltySubject> unavailableRoomPenaltySubjectList) {
		this.unavailableRoomPenaltySubjectList = unavailableRoomPenaltySubjectList;
	}
	@ProblemFactCollectionProperty
	public List<UnavailablePeriodPenaltySubject> getUnavailablePeriodPenaltySubjectList() {
		return unavailablePeriodPenaltySubjectList;
	}

	public void setUnavailablePeriodPenaltySubjectList(List<UnavailablePeriodPenaltySubject> unavailablePeriodPenaltySubjectList) {
		this.unavailablePeriodPenaltySubjectList = unavailablePeriodPenaltySubjectList;
	}


	@ProblemFactCollectionProperty
	public List<WantCourseCompactnessSubject> getWantCourseCompactnessSubjectList() {
		return wantCourseCompactnessSubjectList;
	}

	public void setWantCourseCompactnessSubjectList(List<WantCourseCompactnessSubject> wantCourseCompactnessSubjectList) {
		this.wantCourseCompactnessSubjectList = wantCourseCompactnessSubjectList;
	}
	@ProblemFactCollectionProperty
	public List<WantTwoCourseCompactnessSubject> getWantTwoCourseCompactnessSubjectList() {
		return wantTwoCourseCompactnessSubjectList;
	}

	public void setWantTwoCourseCompactnessSubjectList(List<WantTwoCourseCompactnessSubject> wantTwoCourseCompactnessSubjectList) {
		this.wantTwoCourseCompactnessSubjectList = wantTwoCourseCompactnessSubjectList;
	}

	@ProblemFactCollectionProperty
	public List<WantavailablePeriodPenaltySubject> getWantavailablePeriodPenaltySubjectList() {
		return wantavailablePeriodPenaltySubjectList;
	}

	public void setWantavailablePeriodPenaltySubjectList(List<WantavailablePeriodPenaltySubject> wantavailablePeriodPenaltySubjectList) {
		this.wantavailablePeriodPenaltySubjectList = wantavailablePeriodPenaltySubjectList;
	}

	
	@ProblemFactCollectionProperty
	public List<AWeekBestNoCourse> getAweekBestNoCourseList() {
		return aweekBestNoCourseList;
	}

	public void setAweekBestNoCourseList(List<AWeekBestNoCourse> aweekBestNoCourseList) {
		this.aweekBestNoCourseList = aweekBestNoCourseList;
	}

	
	@ProblemFactCollectionProperty
	public List<WantavailabletimeslotPenaltyCoursenature> getWantavailabletimeslotPenaltyCoursenatureList() {
		return wantavailabletimeslotPenaltyCoursenatureList;
	}

	public void setWantavailabletimeslotPenaltyCoursenatureList(
			List<WantavailabletimeslotPenaltyCoursenature> wantavailabletimeslotPenaltyCoursenatureList) {
		this.wantavailabletimeslotPenaltyCoursenatureList = wantavailabletimeslotPenaltyCoursenatureList;
	}
	@ProblemFactCollectionProperty
	public List<WantavailabletimeslotPenaltyNoCourse> getWantavailabletimeslotPenaltyNoCourseList() {
		return wantavailabletimeslotPenaltyNoCourseList;
	}

	public void setWantavailabletimeslotPenaltyNoCourseList(List<WantavailabletimeslotPenaltyNoCourse> wantavailabletimeslotPenaltyNoCourseList) {
		this.wantavailabletimeslotPenaltyNoCourseList = wantavailabletimeslotPenaltyNoCourseList;
	}
	@ProblemFactCollectionProperty
	public List<WantavailablePeriodPenalty1> getWantavailablePeriodPenaltyList1() {
		return wantavailablePeriodPenaltyList1;
	}

	public void setWantavailablePeriodPenaltyList1(List<WantavailablePeriodPenalty1> wantavailablePeriodPenaltyList1) {
		this.wantavailablePeriodPenaltyList1 = wantavailablePeriodPenaltyList1;
	}

	@ProblemFactCollectionProperty
	public List<UnavailableTimeslotPenaltySubject> getUnavailableTimeslotPenaltySubjectList() {
		return unavailableTimeslotPenaltySubjectList;
	}

	public void setUnavailableTimeslotPenaltySubjectList(List<UnavailableTimeslotPenaltySubject> unavailableTimeslotPenaltySubjectList) {
		this.unavailableTimeslotPenaltySubjectList = unavailableTimeslotPenaltySubjectList;
	}
	@ProblemFactCollectionProperty
	public List<WantavailableTimeslotPenaltySubject> getWantavailableTimeslotPenaltySubjectList() {
		return wantavailableTimeslotPenaltySubjectList;
	}

	public void setWantavailableTimeslotPenaltySubjectList(List<WantavailableTimeslotPenaltySubject> wantavailableTimeslotPenaltySubjectList) {
		this.wantavailableTimeslotPenaltySubjectList = wantavailableTimeslotPenaltySubjectList;
	}

	
    @PlanningEntityCollectionProperty
    public List<Lecture> getLectureList() {
        return lectureList;
    }

    public void setLectureList(List<Lecture> lectureList) {
        this.lectureList = lectureList;
    }

    @PlanningScore
    public HardSoftScore getScore() {
        return score;
    }

    public void setScore(HardSoftScore score) {
        this.score = score;
    }

    // ************************************************************************
    // Complex methods
    // ************************************************************************

    @ProblemFactCollectionProperty
    private List<CourseConflict> calculateCourseConflictList() {
        List<CourseConflict> courseConflictList = new ArrayList<>();
        for (Course leftCourse : courseList) {
            for (Course rightCourse : courseList) {
                if (leftCourse.getId() < rightCourse.getId()) {
                    int conflictCount = 0;
                    if (leftCourse.getTeacher().equals(rightCourse.getTeacher())) {
                        conflictCount++;
                    }
                  //以后添加新的东西不添加下面的
//                    if(leftCourse.getCoursenature().equals(rightCourse.getCoursenature())) {
//                    	conflictCount++;
//                    }
//                    if (leftCourse.getMajor().equals(rightCourse.getMajor())) {
//                        conflictCount++;
//                    }
                  
                    for (Curriculum curriculum : leftCourse.getCurriculumList()) {
                        if (rightCourse.getCurriculumList().contains(curriculum)) {
                            conflictCount++;
                        }
                    }
                    
//                    for (Week week : leftCourse.getWeekList()) {
//                        if (rightCourse.getWeekList().contains(week)) {
//                            conflictCount++;
//                        }
//                    }
                    if (conflictCount > 0) {
                        courseConflictList.add(new CourseConflict(leftCourse, rightCourse, conflictCount));
                    }
                }
            }
        }
        return courseConflictList;
    }

	
	
	
	


	

	
	



	
	

	
	


	
	

	

}
