package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
@XStreamAlias("Subject")
public class Subject extends AbstractPersistable{
	  private String code;
	  private Coursenature coursenature;
	  private Major major;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Coursenature getCoursenature() {
		return coursenature;
	}
	public void setCoursenature(Coursenature coursenature) {
		this.coursenature = coursenature;
	}
	public Major getMajor() {
		return major;
	}
	public void setMajor(Major major) {
		this.major = major;
	}

    @Override
    public String toString() {
        return code;
    }
}
