package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WantavailableCoursenaturePenalty")
public class WantavailableCoursenaturePenalty  extends AbstractPersistable{
	private Coursenature coursenature;
    private AWeek aweek;
    private Timeslot timeslot;
    private int weight;
    
  	public AWeek getAweek() {
		return aweek;
	}
	public void setAweek(AWeek aweek) {
		this.aweek = aweek;
	}
	public Timeslot getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(Timeslot timeslot) {
		this.timeslot = timeslot;
	}
	public int getWeight() {
  		return weight;
  	}
  	public void setWeight(int weight) {
  		this.weight = weight;
  	}
	public Coursenature getCoursenature() {
		return coursenature;
	}
	public void setCoursenature(Coursenature coursenature) {
		this.coursenature = coursenature;
	}
	
	@Override
    public String toString() {
        return coursenature + "@" + aweek+"@"+weight+timeslot;
    }
}
