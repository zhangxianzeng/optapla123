package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WantavailablePeriodPenalty1")
public class WantavailablePeriodPenalty1  extends AbstractPersistable{
	private Subject subject;
   
   private AWeek aweek;
    private int weight;
    private Timeslot timeslot;
    private Curriculum curriculum;
   	public Curriculum getCurriculum() {
   		return curriculum;
   	}
   	public void setCurriculum(Curriculum curriculum) {
   		this.curriculum = curriculum;
   	}
     
  	public Timeslot getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(Timeslot timeslot) {
		this.timeslot = timeslot;
	}
	public AWeek getAweek() {
		return aweek;
	}
	public void setAweek(AWeek aweek) {
		this.aweek = aweek;
	}
	public int getWeight() {
  		return weight;
  	}
  	public void setWeight(int weight) {
  		this.weight = weight;
  	}
   
   
	
	
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	@Override
    public String toString() {
        return subject + "@" + aweek+"@"+weight+"@"+curriculum;
    }

}
