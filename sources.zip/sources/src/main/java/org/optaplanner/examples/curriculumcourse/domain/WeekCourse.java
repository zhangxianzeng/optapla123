package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WeekCourse")
public class WeekCourse extends AbstractPersistable{
private Week week;
private Course course;
private int lectureSize;
private int index;

public int getIndex() {
	return index;
}
public void setIndex(int index) {
	this.index = index;
}
public int getLectureSize() {
	return lectureSize;
}
public void setLectureSize(int lectureSize) {
	this.lectureSize = lectureSize;
}
public Week getWeek() {
	return week;
}
public void setWeek(Week week) {
	this.week = week;
}
public Course getCourse() {
	return course;
}
public void setCourse(Course course) {
	this.course = course;
}
@Override
public String toString() {
    return week+"@"+course;
}

}
