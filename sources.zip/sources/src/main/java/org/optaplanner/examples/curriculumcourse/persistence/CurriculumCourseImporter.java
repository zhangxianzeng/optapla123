/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.optaplanner.examples.curriculumcourse.persistence;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.optaplanner.examples.common.persistence.AbstractTxtSolutionImporter;
import org.optaplanner.examples.common.persistence.SolutionConverter;
import org.optaplanner.examples.curriculumcourse.app.CurriculumCourseApp;
import org.optaplanner.examples.curriculumcourse.domain.AWeek;
import org.optaplanner.examples.curriculumcourse.domain.Course;
import org.optaplanner.examples.curriculumcourse.domain.CourseSchedule;
import org.optaplanner.examples.curriculumcourse.domain.Coursenature;
import org.optaplanner.examples.curriculumcourse.domain.Curriculum;
import org.optaplanner.examples.curriculumcourse.domain.Day;
import org.optaplanner.examples.curriculumcourse.domain.Lecture;
import org.optaplanner.examples.curriculumcourse.domain.Major;
import org.optaplanner.examples.curriculumcourse.domain.Period;
import org.optaplanner.examples.curriculumcourse.domain.Room;
import org.optaplanner.examples.curriculumcourse.domain.Subject;
import org.optaplanner.examples.curriculumcourse.domain.Teacher;
import org.optaplanner.examples.curriculumcourse.domain.Timeslot;
import org.optaplanner.examples.curriculumcourse.domain.UnavailablePeriodPenalty;
import org.optaplanner.examples.curriculumcourse.domain.Week;
import org.optaplanner.examples.curriculumcourse.domain.WeekCourse;

public class CurriculumCourseImporter extends AbstractTxtSolutionImporter<CourseSchedule> {

    private static final String INPUT_FILE_SUFFIX = "xml";

    public static void main(String[] args) {
        SolutionConverter<CourseSchedule> converter = SolutionConverter.createImportConverter(
                CurriculumCourseApp.DATA_DIR_NAME, new CurriculumCourseImporter(), CourseSchedule.class);
        converter.convertAll();
    }

    @Override
    public String getInputFileSuffix() {
        return INPUT_FILE_SUFFIX;
    }

    @Override
    public TxtInputBuilder<CourseSchedule> createTxtInputBuilder() {
        return new CurriculumCourseInputBuilder();
    }

    public static class CurriculumCourseInputBuilder extends TxtInputBuilder<CourseSchedule> {

        @Override
        public CourseSchedule readSolution() throws IOException {
            CourseSchedule schedule = new CourseSchedule();
            schedule.setId(0L);
            // Name: ToyExample
            schedule.setName(readStringValue("Name:"));
            // Courses: 4
            int courseListSize = readIntegerValue("Courses:");
            // Rooms: 2
            int roomListSize = readIntegerValue("Rooms:");
            int weekListSize = readIntegerValue("Weeks:");
            // Days: 5
            int weekCourseListSize=readIntegerValue("weekCourse:");
            int dayListSize = readIntegerValue("Days:");
            int subjectListSize = readIntegerValue("Subjects:");
            // Periods_per_day: 4
            int timeslotListSize = readIntegerValue("Periods_per_day:");
            // Curricula: 2
            int curriculumListSize = readIntegerValue("Curricula:");
            
            // Constraints: 8
            int unavailablePeriodPenaltyListSize = readIntegerValue("Constraints:");

            Map<String, Course> courseMap = readCourseListAndTeacherList(
                    schedule, courseListSize);
            readRoomList(
                    schedule, roomListSize);
            Map<List<Integer>, Period> periodMap = createPeriodListAndDayListAndTimeslotList(
                    schedule, weekListSize,dayListSize, timeslotListSize);
            readCurriculumList(
                    schedule, courseMap, curriculumListSize);
            
            readWeekCourseList(
                    schedule,weekCourseListSize);
            
//            readUnavailablePeriodPenaltyList(
//                    schedule, weekCourseMap, periodMap, unavailablePeriodPenaltyListSize);
            readEmptyLine();
            readConstantLine("END\\.");
            createLectureList(schedule);

            int possibleForOneLectureSize = schedule.getPeriodList().size() * schedule.getRoomList().size();
            BigInteger possibleSolutionSize = BigInteger.valueOf(possibleForOneLectureSize).pow(
                    schedule.getLectureList().size());
            logger.info("CourseSchedule {} has {} teachers, {} curricula, {} courses, {} lectures," +
                    " {} periods, {} rooms and {} unavailable period constraints with a search space of {}.",
                    getInputId(),
                    schedule.getTeacherList().size(),
                    schedule.getMajorList().size(),
                    schedule.getSubjectList().size(),
                    schedule.getAweekList().size(),
                    schedule.getCoursenatureList().size(),
                    schedule.getCurriculumList().size(),
                    schedule.getWeekCourseList().size(),
                    schedule.getWeekList().size(),
                    schedule.getCourseList().size(),
                    schedule.getLectureList().size(),
                    schedule.getDayList().size(),
                    schedule.getPeriodList().size(),
                    schedule.getRoomList().size(),
                    schedule.getUnavailablePeriodPenaltyList().size(),
                    getFlooredPossibleSolutionSize(possibleSolutionSize));
            return schedule;
        }

        private Map<String, Course> readCourseListAndTeacherList(
                CourseSchedule schedule, int courseListSize) throws IOException {
            Map<String, Course> courseMap = new HashMap<>(courseListSize);
            Map<String, Teacher> teacherMap = new HashMap<>();
            Map<String, Subject> subjectMap = new HashMap<>();
            List<Course> courseList = new ArrayList<>(courseListSize);
            readEmptyLine();
            readConstantLine("COURSES:");
            for (int i = 0; i < courseListSize; i++) {
                Course course = new Course();
                course.setId((long) i);
                course.setId1((long) i);
                // Courses: <CourseID> <Teacher> <# Lectures> <MinWorkingDays> <# Students>
                String line = bufferedReader.readLine();
                String[] lineTokens = splitBySpacesOrTabs(line, 5);
                course.setCode(lineTokens[0]);
                course.setTeacher(findOrCreateTeacher(teacherMap, lineTokens[1]));
                course.setSubject(findOrCreateSubject(subjectMap, lineTokens[1]));
              
                //course.setMinWorkingDaySize(Integer.parseInt(lineTokens[4]));
                course.setCurriculumList(new ArrayList<>());
                
                course.setStudentSize(Integer.parseInt(lineTokens[5]));
                courseList.add(course);
                courseMap.put(course.getCode(), course);
            }
            schedule.setCourseList(courseList);
            List<Teacher> teacherList = new ArrayList<>(teacherMap.values());
            schedule.setTeacherList(teacherList);
            List<Subject> subjectList = new ArrayList<>(subjectMap.values());
            schedule.setSubjectList(subjectList);
            
            return courseMap;
        }

        private Teacher findOrCreateTeacher(Map<String, Teacher> teacherMap, String code) {
            Teacher teacher = teacherMap.get(code);
            if (teacher == null) {
                teacher = new Teacher();
                int id = teacherMap.size();
                teacher.setId((long) id);
                teacher.setCode(code);
                teacherMap.put(code, teacher);
            }
            return teacher;
        }
        private Subject findOrCreateSubject(Map<String, Subject> subjectMap, String code) throws IOException {
        	Subject subject = subjectMap.get(code);
        	Map<String, Major> majorMap = new HashMap<>();
            Map<String, Coursenature> coursenatureMap = new HashMap<>();
            if (subject == null) {
            	subject = new Subject();
                int id = subjectMap.size();
                subject.setId((long) id);
                subject.setCode(code);
                String line = bufferedReader.readLine();
                String[] lineTokens = splitBySpacesOrTabs(line, 2);
                subject.setMajor(findOrCreateMajor(majorMap, lineTokens[1]));
                subject.setCoursenature(findOrCreateCoursenature(coursenatureMap, lineTokens[2]));
                subjectMap.put(code, subject);
                
            }
            return subject;
            
        }
        
        private Major findOrCreateMajor(Map<String, Major> majorMap, String code) {
            Major major = majorMap.get(code);
            if (major == null) {
                major = new Major();
                int id = majorMap.size();
                major.setId((long) id);
                major.setCode(code);
                majorMap.put(code, major);
            }
            return major;
        }

        
        private AWeek findOrCreateAWeek(Map<String, AWeek> aweekMap, String code) {
        	AWeek aweek = aweekMap.get(code);
            if (aweek == null) {
            	aweek = new AWeek();
                int id = aweekMap.size();
                aweek.setId((long) id);
                aweek.setCode(code);
                aweekMap.put(code, aweek);
            }
            return aweek;
        }
        
        private Coursenature findOrCreateCoursenature(Map<String, Coursenature> coursenatureMap, String code) {
        	Coursenature coursenature = coursenatureMap.get(code);
            if (coursenature == null) {
            	coursenature = new Coursenature();
                int id = coursenatureMap.size();
                coursenature.setId((long) id);
                coursenature.setCode(code);
                coursenatureMap.put(code, coursenature);
            }
            return coursenature;
        }


        
        private Course findOrCreateCourse(Map<String, Course> courseMap, String code) {
        	Course course=courseMap.get(code);
        	if(course==null) {
        		course=new Course();
        		int id=courseMap.size();
        		course.setId((long) id);
        		course.setId1((long) id);
        		course.setCode(code);
        		courseMap.put(code, course);
        	}
     			return course;
     		}
    	private Week findOrCreateWeek(Map<String, Week> weekMap, String code) {
			Week week=weekMap.get(code);
			List<Day> dayList=new ArrayList<>();
			List<WeekCourse> weekCourseList=new ArrayList<>();
			if(week==null) {
				week=new Week();
				int id=weekMap.size();
				week.setId((long) id);
				week.setCode(code);
				week.setDayList(dayList);
				week.setWeekCourseList(weekCourseList);
				weekMap.put(code, week);
				
			}
			return week;
		}

 
        
        private void readRoomList(CourseSchedule schedule, int roomListSize)
                throws IOException {
            readEmptyLine();
            readConstantLine("ROOMS:");
            List<Room> roomList = new ArrayList<>(roomListSize);
            Map<String, Major> majorMap = new HashMap<>();
            for (int i = 0; i < roomListSize; i++) {
                Room room = new Room();
                room.setId((long) i);
                // Rooms: <RoomID> <Capacity>
                String line = bufferedReader.readLine();
                String[] lineTokens = splitBySpacesOrTabs(line, 2);
                room.setCode(lineTokens[0]);
                room.setMajor(findOrCreateMajor(majorMap, lineTokens[1]));
                room.setCapacity(Integer.parseInt(lineTokens[1]));
                roomList.add(room);
            }
            schedule.setRoomList(roomList);
        }

        
        
        private void readWeekCourseList(CourseSchedule schedule, int weekCourseListSize)
                throws IOException {
            readEmptyLine();
            readConstantLine("WeekCourse:");
            List<WeekCourse> weekCourseList = new ArrayList<>(weekCourseListSize);
            Map<String, Course> courseMap = new HashMap<>();
            Map<String, Week> weekMap = new HashMap<>();
            for (int i = 0; i < weekCourseListSize; i++) {
            	WeekCourse weekCourse = new WeekCourse();
            	weekCourse.setId((long) i);
                // Rooms: <RoomID> <Capacity>
                String line = bufferedReader.readLine();
                String[] lineTokens = splitBySpacesOrTabs(line, 2);
                weekCourse.setLectureSize(Integer.parseInt(lineTokens[3]));
                weekCourse.setIndex(i);
                weekCourse.setCourse(findOrCreateCourse(courseMap, lineTokens[1]));
                weekCourse.setWeek(findOrCreateWeek(weekMap, lineTokens[1]));
                weekCourseList.add(weekCourse);
            }
            schedule.setWeekCourseList(weekCourseList);
        }
        
        
        
     

	
		private Map<List<Integer>, Period> createPeriodListAndDayListAndTimeslotList(
                CourseSchedule schedule,int weekListSize, int dayListSize, int timeslotListSize) throws IOException {
            int periodListSize = weekListSize*dayListSize* timeslotListSize;
            Map<List<Integer>, Period> periodMap = new HashMap<>(periodListSize);
            List<Week> weekList=new ArrayList<>(weekListSize);
            for(int i = 0; i < weekListSize; i++) {
            	Week week =new Week();
            	week.setId((long)i);
            	week.setDayList(new ArrayList<>(periodListSize));
            	week.setIndex(i);
            	week.setWeekCourseList(new ArrayList<>(periodListSize));
            	weekList.add(week);
            }
            schedule.setWeekList(weekList);
            List<Day> dayList = new ArrayList<>(dayListSize);
            Map<String, AWeek> aweekMap = new HashMap<>();
            for (int i = 0; i < dayListSize; i++) {
            	 String line = bufferedReader.readLine();
                 String[] lineTokens = splitBySpacesOrTabs(line, 2);
                Day day = new Day();
                day.setId((long) i);
                day.setDayIndex(i);
              // day.setIndex(i);
                day.setAweek(findOrCreateAWeek(aweekMap,  lineTokens[1]));
                day.setPeriodList(new ArrayList<>(timeslotListSize));
                dayList.add(day);
            }
            schedule.setDayList(dayList);
            List<Timeslot> timeslotList = new ArrayList<>(timeslotListSize);
            for (int i = 0; i < timeslotListSize; i++) {
                Timeslot timeslot = new Timeslot();
                timeslot.setId((long) i);
                timeslot.setTimeslotIndex(i);
                timeslotList.add(timeslot);
            }
            schedule.setTimeslotList(timeslotList);
            List<Period> periodList = new ArrayList<>(periodListSize);
            for (int i = 0; i < dayListSize; i++) {
                Day day = dayList.get(i);
                Week week=weekList.get(i);
                for (int j = 0; j < timeslotListSize; j++) {
                    Period period = new Period();
                    period.setId((long) (i * timeslotListSize + j));
                    period.setDay(day);
                    period.setTimeslot(timeslotList.get(j));
                    period.setWeek(week);
                 //   period.setIndex(i);
                    periodList.add(period);
                 
                    periodMap.put(Arrays.asList(i, j), period);
                    day.getPeriodList().add(period);
                }
            }
            schedule.setPeriodList(periodList);
            return periodMap;
        }

        private void readCurriculumList(CourseSchedule schedule,
                Map<String, Course> courseMap, int curriculumListSize) throws IOException {
            readEmptyLine();
            readConstantLine("CURRICULA:");
            List<Curriculum> curriculumList = new ArrayList<>(curriculumListSize);
            for (int i = 0; i < curriculumListSize; i++) {
                Curriculum curriculum = new Curriculum();
                curriculum.setId((long) i);
                // Curricula: <CurriculumID> <# Courses> <MemberID> ... <MemberID>
                String line = bufferedReader.readLine();
                String[] lineTokens = splitBySpacesOrTabs(line);
                if (lineTokens.length < 2) {
                    throw new IllegalArgumentException("Read line (" + line
                            + ") is expected to contain at least 2 tokens.");
                }
                curriculum.setCode(lineTokens[0]);
                int coursesInCurriculum = Integer.parseInt(lineTokens[1]);
                if (lineTokens.length != (coursesInCurriculum + 2)) {
                    throw new IllegalArgumentException("Read line (" + line + ") is expected to contain "
                            + (coursesInCurriculum + 2) + " tokens.");
                }
                for (int j = 2; j < lineTokens.length; j++) {
                    Course course = courseMap.get(lineTokens[j]);
                    if (course == null) {
                        throw new IllegalArgumentException("Read line (" + line + ") uses an unexisting course("
                                + lineTokens[j] + ").");
                    }
                    course.getCurriculumList().add(curriculum);
                }
                curriculumList.add(curriculum);
            }
            schedule.setCurriculumList(curriculumList);
        }

        
        
        
        

        
        
        
        
        
        
        
        private void readUnavailablePeriodPenaltyList(CourseSchedule schedule, Map<String, Subject> subjectMap,
                Map<List<Integer>, Timeslot> timeslotMap, Map<List<Integer>, AWeek> aweekMap,int unavailablePeriodPenaltyListSize)
                throws IOException {
            readEmptyLine();
            readConstantLine("UNAVAILABILITY_CONSTRAINTS:");
            List<UnavailablePeriodPenalty> penaltyList = new ArrayList<>(
                    unavailablePeriodPenaltyListSize);
            for (int i = 0; i < unavailablePeriodPenaltyListSize; i++) {
                UnavailablePeriodPenalty penalty = new UnavailablePeriodPenalty();
                penalty.setId((long) i);
                // Unavailability_Constraints: <CourseID> <Day> <Day_Period>
                String line = bufferedReader.readLine();
                String[] lineTokens = splitBySpacesOrTabs(line, 3);
                penalty.setSubject(subjectMap.get(lineTokens[0]));
                int dayIndex = Integer.parseInt(lineTokens[1]);
                int timeslotIndex = Integer.parseInt(lineTokens[2]);
                Timeslot timeslot = timeslotMap.get(Arrays.asList(dayIndex, timeslotIndex));
                AWeek aweek = aweekMap.get(Arrays.asList(dayIndex, timeslotIndex));
                if (aweek == null&&timeslot==null) {
                    throw new IllegalArgumentException("Read line (" + line + ") uses an unexisting period("
                            + dayIndex + " " + timeslotIndex + ").");
                }
                penalty.setAweek(aweek);
                penalty.setTimeslot(timeslot);
                penaltyList.add(penalty);
            }
            schedule.setUnavailablePeriodPenaltyList(penaltyList);
        }
        private void createLectureList(CourseSchedule schedule) {
            List<WeekCourse> weekCourseList = schedule.getWeekCourseList();
            List<Lecture> lectureList = new ArrayList<>(weekCourseList.size());
            long id = 0L;
            for (WeekCourse weekCourse : weekCourseList) {
                for (int i = 0; i < weekCourse.getLectureSize(); i++) {
                    Lecture lecture = new Lecture();
                    lecture.setId(id);
                    id++;
                    lecture.setWeekCourse(weekCourse);
                    lecture.setLectureIndexInCourse(i);
                    lecture.setLocked(false);
                    // Notice that we leave the PlanningVariable properties on null
                    lectureList.add(lecture);
                }
            }
            schedule.setLectureList(lectureList);
        }

    }

}
