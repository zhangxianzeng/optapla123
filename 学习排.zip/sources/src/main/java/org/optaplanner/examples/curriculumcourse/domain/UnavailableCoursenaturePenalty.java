package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("UnavailableCoursenaturePenalty")
public class UnavailableCoursenaturePenalty  extends AbstractPersistable{
	private Coursenature coursenature;
    private Timeslot timeslot;
    private int weight;
    
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public Coursenature getCoursenature() {
		return coursenature;
	}
	public void setCoursenature(Coursenature coursenature) {
		this.coursenature = coursenature;
	}
	
	public Timeslot getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(Timeslot timeslot) {
		this.timeslot = timeslot;
	}
	@Override
    public String toString() {
        return coursenature + "@" + timeslot+"@"+weight;
    }
}
